<?php

add_action( 'generate_rewrite_rules', 'event_rewrite_rule');
function event_rewrite_rule($wp_rewrite){

	$rules = array(
	'json' => 'index.php?json=fiftyevents'
	);

	$wp_rewrite->rules = $rules + $wp_rewrite->rules;
}


add_action( 'query_vars', 'events_query_vars');
function events_query_vars($vars){
	$vars[] = 'json';
	return $vars;
}

add_action( 'template_include', 'events_template_include' );
function events_template_include( $template ) {
	
	// check if we have an action or a template
	if(is_singular('events')){
		$new_template = MYABSPATH . '/templates/singleevent.php';
		$template   = $new_template;

	} //close if condition
	
	elseif(get_query_var( 'taxonomy' ) == 'event-custom-category') {
		//die('ok');
		$new_template = MYABSPATH . '/templates/multievent.php';
		$template   = $new_template;
	}  //end elseif condition
	elseif(get_query_var( 'json' ) == 'fiftyevents' ) { // TEMP code
		//die('ok');
		$new_template = MYABSPATH . '/templates/events-json.php';
		$template   = $new_template;
	}
		return $template;
}

?>