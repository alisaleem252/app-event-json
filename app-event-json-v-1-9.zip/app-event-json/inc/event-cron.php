<?php
add_action('old_events_trashing','eventTrashing_daily');
 	
function eventTrashing_daily(){


	$args = array(
	'post_type' => 'events',
	'posts_per_page'   => -1,
	'post_status' => 'publish'
		);
	$eventPosts = get_posts($args);
		if($eventPosts){
			foreach($eventPosts as $eventPost){
			$eventTZ_DB = get_post_meta($eventPost->ID,'event-time-zone',true);

				$eventED_DB = get_post_meta($eventPost->ID,'event-enddate',true);
				$eventET_DB = get_post_meta($eventPost->ID,'event-endtime',true);
				$db_dt_stamp = strtotime("$eventED_DB $eventET_DB");
				
	$dtz = new DateTimeZone($eventTZ_DB);
	$time_of_dtz = new DateTime("now", $dtz);
	$offset = $dtz->getOffset( $time_of_dtz ) / 60;
	
	$current_dt_stamp = (strtotime("$offset minutes",strtotime(Date('Y-m-d h:i A'))));
				
				if(get_post_meta(get_the_ID(), 'event-fulldayCB', true) == 'on'){
					$eventSD_DB = get_post_meta($eventPost->ID,'event-startdate',true);
					$eventST_DB = get_post_meta($eventPost->ID,'event-starttime',true);
					$db_dt_stamp = strtotime("$eventSD_DB $eventST_DB");
					
						if($db_dt_stamp <  $current_dt_stamp)
							wp_trash_post($eventPost->ID);
				}
				else{
						if($db_dt_stamp <  $current_dt_stamp)
						wp_trash_post($eventPost->ID);
					} // ELSE     if(get_post_meta(get_the_ID(), 'event-fulldayCB', true) == 'on')
				
			} // END foreach($eventPosts as $eventPost)
			
		} // END if($eventPosts)
}  //end function

?>