<?php

// i18n plugin domain
define('DUPLICATE_POST_I18N_DOMAIN', 'eventmanagementjson');

// Version of the plugin
define('DUPLICATE_POST_CURRENT_VERSION', '44' );

/**
 * Initialise the internationalisation domain
 */
load_plugin_textdomain(DUPLICATE_POST_I18N_DOMAIN,
			'wp-content/plugins/duplicate-post/languages','duplicate-post/languages');

//add_filter("plugin_action_links_".plugin_basename(__FILE__), "duplicate_post_plugin_actions", 10, 4);

function duplicate_post_plugin_actions( $actions, $plugin_file, $plugin_data, $context ) {
	array_unshift($actions, "<a href=\"".menu_page_url('duplicatepost', false)."\">".__("Settings")."</a>");
	return $actions;
}

require_once (MYABSPATH.'/inc/duplicate-post-common.php');

if (is_admin()){
	require_once (MYABSPATH.'/inc/duplicate-post-admin.php');
}
?>