<?php // Post Metas of Event Management Class

class event_post_metas{

	// Constructors of Post Metas (ADD ACTION) of Event Management Class
	function __construct(){
		add_action('add_meta_boxes',array(&$this,'event_metabox'));
		add_action('save_post',array(&$this,'save_event_metabox'));
	}

	// Inserting the Meta Box
	function event_metabox(){
		 //add_meta_box( $id, $title, $callback, $post_type, $context,$priority, $callback_args );
		 add_meta_box('eventPostmetas','Event Date/Time & Venue Settings',array(&$this,'add_event_metabox'),'events','normal','high');
	} // END function event_metabox()
	
	// Defining the Meta Box
	function add_event_metabox(){  
	/*
	$eventED_DB = get_post_meta(get_the_ID(),'event-enddate',true);
	$eventET_DB = get_post_meta(get_the_ID(),'event-endtime',true);
	$eventTZ_DB = get_post_meta(get_the_ID(),'event-time-zone',true);
				echo $eventTZ_DB;
	$db_dt_stamp = strtotime("$eventED_DB $eventET_DB");
	$dtz = new DateTimeZone($eventTZ_DB);
	$time_of_dtz = new DateTime("now", $dtz);
	$offset = $dtz->getOffset( $time_of_dtz ) / 60;
	
	$current_dt_stamp = (strtotime("$offset minutes",strtotime(Date('Y-m-d h:i A'))));
	
	
	echo $db_dt_stamp.' SPACE '.$current_dt_stamp;
	if($db_dt_stamp <  $current_dt_stamp)
	echo 'Should be deleted';*/
				
				
				
				
			$venues = get_terms('venue-custom-category','hide_empty=0');
//print_r($venues);
	?>
		<script> jQuery(document).ready(function(){ initialize(); }); </script>
		<table>
			<tr>
				<th width="150px" style="text-align:left" ><?php _e('Event Timezone Area', 'Eventmanagement'); $event_tz = get_post_meta(get_the_ID(),'event-time-zone',true) ?></th>
				<td>
					<select name="timezone">
                    
<option value="Europe/Copenhagen"  <?php echo ($event_tz == 'Europe/Copenhagen' ? 'selected' : ''); ?> >Copenhagen</option>
<option value="Africa/Algiers"  <?php echo ($event_tz == 'Africa/Algiers' ? 'selected' : ''); ?> >West Central Africa</option>
<option value="Europe/Amsterdam" <?php echo ($event_tz == 'Europe/Amsterdam' ? 'selected' : ''); ?> >Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna</option>
<option value="Europe/Belgrade" <?php echo ($event_tz == 'Europe/Belgrade' ? 'selected' : ''); ?> >Belgrade, Bratislava, Budapest, Ljubljana, Prague</option>
<option value="Europe/Brussels" <?php echo ($event_tz == 'Europe/Brussels' ? 'selected' : ''); ?> >Brussels, Copenhagen, Madrid, Paris</option>
<option value="Africa/Windhoek" <?php echo ($event_tz == 'Africa/Windhoek' ? 'selected' : ''); ?> >Windhoek</option>
<option value="Asia/Beirut" <?php echo ($event_tz == 'Asia/Beirut' ? 'selected' : ''); ?> >Beirut</option>
<option value="Africa/Cairo" <?php echo ($event_tz == 'Africa/Cairo' ? 'selected' : ''); ?> >Cairo</option>
<option value="Asia/Gaza" <?php echo ($event_tz == 'Asia/Gaza' ? 'selected' : ''); ?> >Gaza</option>
<option value="Africa/Blantyre" <?php echo ($event_tz == 'Africa/Blantyre' ? 'selected' : ''); ?> >Harare, Blantyre, Pretoria</option>
<option value="Asia/Jerusalem" <?php echo ($event_tz == 'Asia/Jerusalem' ? 'selected' : ''); ?> >Jerusalem</option>
<option value="Europe/Minsk" <?php echo ($event_tz == 'Europe/Minsk' ? 'selected' : ''); ?> >Minsk</option>
<option value="Asia/Damascus" <?php echo ($event_tz == 'Asia/Damascus' ? 'selected' : ''); ?> >Damascus ,Syria</option>
<option value="Europe/Moscow" <?php echo ($event_tz == 'Europe/Moscow' ? 'selected' : ''); ?> >Moscow, St. Petersburg, Volgograd</option>
<option value="Africa/Addis_Ababa" <?php echo ($event_tz == 'Africa/Addis_Ababa' ? 'selected' : ''); ?> >Addis_Ababa, Nairobi</option>
<option value="Asia/Tehran" <?php echo ($event_tz == 'Asia/Tehran' ? 'selected' : ''); ?> >Tehran</option>
<option value="Asia/Riyadh" <?php echo ($event_tz == 'Asia/Riyadh' ? 'selected' : ''); ?> >Saudi Arabia, Riyadh</option>
<option value="Asia/Dubai" <?php echo ($event_tz == 'Asia/Dubai' ? 'selected' : ''); ?> >Abu Dhabi, Muscat</option>
<option value="Asia/Yerevan" <?php echo ($event_tz == 'Asia/Yerevan' ? 'selected' : ''); ?> >Yerevan</option>
<option value="Asia/Kabul" <?php echo ($event_tz == 'Asia/Kabul' ? 'selected' : ''); ?> >Kabul</option>
<option value="Asia/Yekaterinburg" <?php echo ($event_tz == 'Asia/Yekaterinburg' ? 'selected' : ''); ?> >Ekaterinburg</option>
<option value="Asia/Karachi" <?php echo ($event_tz == 'Asia/Karachi' ? 'selected' : ''); ?> >Karachi, Islamabad</option>
<option value="Asia/Tashkent" <?php echo ($event_tz == 'Asia/Tashkent' ? 'selected' : ''); ?> >Tashkent</option>
<option value="Asia/Kolkata" <?php echo ($event_tz == 'Asia/Kolkata' ? 'selected' : ''); ?> >Chennai, Kolkata, Mumbai, New Delhi</option>
<option value="Asia/Katmandu" <?php echo ($event_tz == 'Asia/Katmandu' ? 'selected' : ''); ?> >Kathmandu</option>
<option value="Asia/Dhaka" <?php echo ($event_tz == 'Asia/Dhaka' ? 'selected' : ''); ?> >Astana, Dhaka</option>
<option value="Asia/Novosibirsk" <?php echo ($event_tz == 'Asia/Novosibirsk' ? 'selected' : ''); ?> >Novosibirsk</option>
<option value="Asia/Rangoon" <?php echo ($event_tz == 'Asia/Rangoon' ? 'selected' : ''); ?> >Yangon (Rangoon)</option>
<option value="Asia/Bangkok" <?php echo ($event_tz == 'Asia/Bangkok' ? 'selected' : ''); ?> >Bangkok, Hanoi, Jakarta</option>
<option value="Asia/Krasnoyarsk" <?php echo ($event_tz == 'Asia/Krasnoyarsk' ? 'selected' : ''); ?> >Krasnoyarsk</option>
<option value="Asia/Hong_Kong" <?php echo ($event_tz == 'Asia/Hong_Kong' ? 'selected' : ''); ?> >Beijing, Chongqing, Hong Kong, Urumqi</option>
<option value="Asia/Irkutsk" <?php echo ($event_tz == 'Asia/Irkutsk' ? 'selected' : ''); ?> >Irkutsk, Ulaan Bataar</option>
<option value="Australia/Perth" <?php echo ($event_tz == 'Australia/Perth' ? 'selected' : ''); ?> >Perth</option>
<option value="Australia/Eucla" <?php echo ($event_tz == 'Australia/Eucla' ? 'selected' : ''); ?> >Eucla</option>
<option value="Asia/Tokyo" <?php echo ($event_tz == 'Asia/Tokyo' ? 'selected' : ''); ?> >Osaka, Sapporo, Tokyo</option>
<option value="Asia/Seoul" <?php echo ($event_tz == 'Asia/Seoul' ? 'selected' : ''); ?> >Seoul</option>
<option value="Asia/Yakutsk" <?php echo ($event_tz == 'Asia/Yakutsk' ? 'selected' : ''); ?> >Yakutsk</option>
<option value="Australia/Adelaide" <?php echo ($event_tz == 'Australia/Adelaide' ? 'selected' : ''); ?> >Adelaide</option>
<option value="Australia/Darwin" <?php echo ($event_tz == 'Australia/Darwin' ? 'selected' : ''); ?> >Darwin</option>
<option value="Australia/Brisbane" <?php echo ($event_tz == 'Australia/Brisbane' ? 'selected' : ''); ?> >Brisbane</option>
<option value="Australia/Hobart" <?php echo ($event_tz == 'Australia/Hobart' ? 'selected' : ''); ?> >Hobart</option>
<option value="Asia/Vladivostok" <?php echo ($event_tz == 'Asia/Vladivostok' ? 'selected' : ''); ?> >Vladivostok</option>
<option value="Australia/Lord_Howe" <?php echo ($event_tz == 'Australia/Lord_Howe' ? 'selected' : ''); ?> >Lord Howe Island</option>
<option value="Etc/GMT-11" <?php echo ($event_tz == 'Etc/GMT-11' ? 'selected' : ''); ?> >Solomon Is., New Caledonia</option>
<option value="Asia/Magadan" <?php echo ($event_tz == 'Asia/Magadan' ? 'selected' : ''); ?> >Magadan</option>
<option value="Pacific/Norfolk" <?php echo ($event_tz == 'Pacific/Norfolk' ? 'selected' : ''); ?> >Norfolk Island</option>
<option value="Asia/Anadyr" <?php echo ($event_tz == 'Asia/Anadyr' ? 'selected' : ''); ?> >Anadyr, Kamchatka</option>
<option value="Pacific/Auckland" <?php echo ($event_tz == 'Pacific/Auckland' ? 'selected' : ''); ?> >Auckland, Wellington</option>
<option value="Pacific/Midway" <?php echo ($event_tz == 'Pacific/Midway' ? 'selected' : ''); ?> >Midway Island, Samoa</option>
<option value="America/Adak" <?php echo ($event_tz == 'America/Adak' ? 'selected' : ''); ?> >Adak, Hawaii-Aleutian</option>
<option value="Etc/GMT+10" <?php echo ($event_tz == 'Etc/GMT+10' ? 'selected' : ''); ?> >Hawaii</option>
<option value="Pacific/Marquesas" <?php echo ($event_tz == 'Pacific/Marquesas' ? 'selected' : ''); ?> >Marquesas Islands</option>
<option value="Pacific/Gambier" <?php echo ($event_tz == 'Pacific/Gambier' ? 'selected' : ''); ?> >Gambier Islands</option>
<option value="America/Anchorage" <?php echo ($event_tz == 'America/Anchorage' ? 'selected' : ''); ?> >Alaska</option>
<option value="America/Ensenada" <?php echo ($event_tz == 'America/Ensenada' ? 'selected' : ''); ?> >Tijuana, Baja California</option>
<option value="Etc/GMT+8" <?php echo ($event_tz == 'Etc/GMT+8' ? 'selected' : ''); ?> >Pitcairn Islands</option>
<option value="America/Los_Angeles" <?php echo ($event_tz == 'America/Los_Angeles' ? 'selected' : ''); ?> >Los_Angeles, Pacific Time (US & Canada)</option>
<option value="America/Denver" <?php echo ($event_tz == 'America/Denver' ? 'selected' : ''); ?> >Denver, Mountain Time (US & Canada)</option>
<option value="America/Chihuahua" <?php echo ($event_tz == 'America/Chihuahua' ? 'selected' : ''); ?> >Chihuahua, Mazatlan</option>
<option value="America/Dawson_Creek" <?php echo ($event_tz == 'America/Dawson_Creek' ? 'selected' : ''); ?> >Arizona</option>
<option value="America/Belize" <?php echo ($event_tz == 'America/Belize' ? 'selected' : ''); ?> >Saskatchewan, Central America,Belize</option>
<option value="America/Cancun" <?php echo ($event_tz == 'America/Cancun' ? 'selected' : ''); ?> >Guadalajara, Mexico City, Monterrey</option>
<option value="Chile/EasterIsland" <?php echo ($event_tz == 'Chile/EasterIsland' ? 'selected' : ''); ?> >Easter Island</option>
<option value="America/Chicago" <?php echo ($event_tz == 'America/Chicago' ? 'selected' : ''); ?> >Chicago. Central Time (US & Canada)</option>
<option value="America/New_York" <?php echo ($event_tz == 'America/New_York' ? 'selected' : ''); ?> >New_York, Eastern Time (US & Canada)</option>
<option value="America/Havana" <?php echo ($event_tz == 'America/Havana' ? 'selected' : ''); ?> >Cuba</option>
<option value="America/Bogota" <?php echo ($event_tz == 'America/Bogota' ? 'selected' : ''); ?> >Bogota, Lima, Quito, Rio Branco</option>
<option value="America/Caracas" <?php echo ($event_tz == 'America/Caracas' ? 'selected' : ''); ?> >Caracas</option>
<option value="America/Santiago" <?php echo ($event_tz == 'America/Santiago' ? 'selected' : ''); ?> >Santiago</option>
<option value="Atlantic/Stanley" <?php echo ($event_tz == 'Atlantic/Stanley' ? 'selected' : ''); ?>>Faukland Islands</option>
<option value="America/Campo_Grande" <?php echo ($event_tz == 'America/Campo_Grande' ? 'selected' : ''); ?>>Campo_Grande, Brazil</option>
<option value="America/Goose_Bay" <?php echo ($event_tz == 'America/Goose_Bay' ? 'selected' : ''); ?>>Atlantic Time (Goose Bay)</option>
<option value="America/Glace_Bay" <?php echo ($event_tz == 'America/Glace_Bay' ? 'selected' : ''); ?>>Atlantic Time (Glace_Bay)</option>
<option value="America/St_Johns" <?php echo ($event_tz == 'America/St_Johns' ? 'selected' : ''); ?>>St_Johns, Newfoundland</option>
<option value="America/Araguaina" <?php echo ($event_tz == 'America/Araguaina' ? 'selected' : ''); ?>>Araguaina</option>
<option value="America/Montevideo" <?php echo ($event_tz == 'America/Montevideo' ? 'selected' : ''); ?>>Montevideo</option>
<option value="America/Miquelon" <?php echo ($event_tz == 'America/Miquelon' ? 'selected' : ''); ?>>Miquelon, St. Pierre</option>
<option value="America/Godthab" <?php echo ($event_tz == 'America/Godthab' ? 'selected' : ''); ?>>Greenland, Godthab</option>
<option value="America/Argentina/Buenos_Aires" <?php echo ($event_tz == 'America/Argentina/Buenos_Aires' ? 'selected' : ''); ?>>Argentina, Buenos Aires</option>
<option value="America/Sao_Paulo" <?php echo ($event_tz == 'America/Sao_Paulo' ? 'selected' : ''); ?>>Brasilia, Sao_Paulo</option>
<option value="America/Noronha" <?php echo ($event_tz == 'America/Noronha' ? 'selected' : ''); ?>>Mid-Atlantic</option>
<option value="Atlantic/Cape_Verde" <?php echo ($event_tz == 'Atlantic/Cape_Verde' ? 'selected' : ''); ?>>Cape Verde Is.</option>
<option value="Atlantic/Azores" <?php echo ($event_tz == 'Atlantic/Azores' ? 'selected' : ''); ?>>Azores</option>
<option value="Europe/Belfast" <?php echo ($event_tz == 'Europe/Belfast' ? 'selected' : ''); ?>>Belfast</option>
<option value="Europe/Dublin" <?php echo ($event_tz == 'Europe/Dublin' ? 'selected' : ''); ?>>Dublin</option>
<option value="Europe/Lisbon" <?php echo ($event_tz == 'Europe/Lisbon' ? 'selected' : ''); ?>>Lisbon</option>
<option value="Europe/London" <?php echo ($event_tz == 'Europe/London' ? 'selected' : ''); ?>>London</option>
<option value="Africa/Abidjan" <?php echo ($event_tz == 'Africa/Abidjan' ? 'selected' : ''); ?>>Abidjan, Monrovia, Reykjavik</option>
					</select>
				</td>
			</tr>		
			<tr>
				<th width="150px" style="text-align:left" ><?php _e( 'Event Start Date & Time', 'Eventmanagement'); ?></th>
				<td><input id="startdate" name="startdate" type="date"  value="<?php echo get_post_meta(get_the_ID(),'event-startdate',true) ?>" required /><input name="starttime" type="time" value="<?php echo get_post_meta(get_the_ID(),'event-starttime',true) ?>" required /> <input id="fulldayCB" name="fulldayCB" type="checkbox" <?php echo (get_post_meta(get_the_ID(),'event-fulldayCB',true) == 'on' ? 'checked' : ''); ?> ><?php _e( 'Full Day Event', 'Eventmanagement'); ?></input></td>
			</tr>
			<tr id="enddateRow">
				<th style="text-align:left" ><?php _e( 'Event End Date & Time', 'Eventmanagement'); ?></th>
				<td><input id="enddate" name="enddate" type="date" min="" value="<?php echo get_post_meta(get_the_ID(),'event-enddate',true); ?>" required /><input id="endtime" name="endtime" type="time" value="<?php echo get_post_meta(get_the_ID(),'event-endtime',true) ?>" required /></td>
			</tr>
			<tr>
				<th style="text-align:left" ><?php _e( 'Link Short Text', 'Eventmanagement'); ?></th>
				<td><input name="linkST" type="text" value="<?php echo get_post_meta(get_the_ID(),'event-linkST',true) ?>" /></td>
			</tr>
			<tr>
				<th style="text-align:left" ><?php _e( 'URL', 'Eventmanagement'); ?></th>
				<td><input name="URL" type="text" value="<?php echo get_post_meta(get_the_ID(),'event-url',true) ?>" /></td>
			</tr>
			<tr>
				<th style="text-align:left" ><?php _e( 'Select Saved Venue', 'Eventmanagement'); ?></th>
				<td>

					<select name="venue">
					<option value="" ><?php _e( 'Select The Venue', 'Eventmanagement'); ?></option>
						<?php
					
				if(!empty($venues)){
					$saveVenueID = 0;
					foreach($venues as $venue){
		$DB_latitude = get_option('latitude-'.$venue->term_id);
		$DB_longitude = get_option('longitude-'.$venue->term_id);
		$DB_venue		= wp_get_post_terms( get_the_ID(), 'venue-custom-category' );
		$DB_venue		= isset($DB_venue[0]) ? $DB_venue[0]->name : '';
	
						if((isset($DB_latitude) && isset($DB_longitude)) && (is_numeric($DB_latitude) && is_numeric($DB_longitude))){
						?>					
							<option value="<?php echo $venue->name ?>" <?php if($DB_venue == $venue->name) {echo 'selected'; $saveVenueID = $venue->term_id; } else echo '' ;  ?> ><?php echo $venue->name ?></option>
				<?php	} // END if((isset($DB_latitude) && isset($DB_longitude)) && (is_float($DB_latitude) && is_float($DB_longitude)))
					} // END foreach($c_mediums as $c_medium)
				} // END if(!empty($venues))
							?> 
					</select>
					<?php $venue_address = get_option('latlong_address-'.$saveVenueID);
						if($venue_address)
							echo "&nbsp;&nbsp;$venue_address";
					?>
				</td>
			</tr>
			<tr> <td colspan="2" style="text-align:center"><hr /><h1>OR</h1><hr /><h1>Add New Venue</h1></td>
			</tr>
			<tr>
				<th style="text-align:left" ><?php _e( 'Venue Short Text/ Label', 'Eventmanagement'); ?></th>
				<td><input name="venueST" type="text" value="<?php if(isset($DB_venue)) echo $DB_venue; ?>" /></td>
			</tr>
			<tr>
				<th colspan=2 ><h2><?php _e( 'Click on the Required Venue for Latitude/Longetude', 'Eventmanagement'); ?></h2></th>
			</tr>
			<tr>
				<td colspan=2 >
				   <div id="map_canvas" style="width: 700px; height: 400px"></div><br />
				</td>
			</tr>
				<tr>
					<td><strong>Latitude/ Longitude:</strong> <input name="longlatitude" onkeyup="showAddress(jQuery(this).val())" type="text" id="showlatlong" /> <strong>Address:</strong> <input id="lati_longi_address" name="lati_longi_address" type="text" /></td>
					<td><input type="button" id="longlatitudeBtn" value="Use This New Address and Latitude/Longitude" onclick="insertLatLong()" /></td>
				</tr>
			<tr>
				<th style="text-align:left" ><?php _e( 'Venue Address: (Latitude/Longetude)', 'Eventmanagement'); ?></th>
				<td><input id="latitude" name="latitude" type="text" title="Enter Digists only" pattern="-?\d*\.{0,1}\d+" onchange="this.setCustomValidity(this.validity.patternMismatch ? '' : '');" /> <input id="longitude" name="longitude" type="float" title="Enter Digists only" pattern="-?\d*\.{0,1}\d+" onchange="this.setCustomValidity(this.validity.patternMismatch ? '' : '');" /> 
				<input name="safe" type="checkbox" ><?php _e( 'Save this New Venue', 'Eventmanagement'); ?></input></td>
			</tr>
		</table>
<?php //print_r(get_post_meta(get_the_ID(),'event-enddate',true));
	} // END function add_event_metabox()

	
			
	
	function save_event_metabox(){
		//die(print_r($_POST['timezone']));
		update_post_meta(get_the_ID(),'event-time-zone',$_POST['timezone']);
		
		if(isset($_POST['startdate']))
			update_post_meta(get_the_ID(),'event-startdate',$_POST['startdate']);
		
		if(isset($_POST['starttime']))
			update_post_meta(get_the_ID(),'event-starttime',$_POST['starttime']);
		
		$fulldayCB = isset($_POST['fulldayCB']) ? $_POST['fulldayCB'] : '';
			update_post_meta(get_the_ID(),'event-fulldayCB',$fulldayCB);
			
		if(isset($_POST['enddate']) && empty($fulldayCB))
			update_post_meta(get_the_ID(),'event-enddate',$_POST['enddate']);
		
		if(isset($_POST['endtime']) && empty($fulldayCB))
			update_post_meta(get_the_ID(),'event-endtime',$_POST['endtime']);

		if(isset($_POST['venue']))
//			update_post_meta(get_the_ID(),'event-venue',$_POST['venue']);
		wp_set_post_terms( get_the_ID(), $_POST['venue'], 'venue-custom-category' );

		
		if(isset($_POST['venueST']) && isset($_POST['latitude']) && isset($_POST['longitude'])){
		$newTerm	= wp_insert_term($_POST['venueST'],'venue-custom-category');
					//die(print_r($newTerm->errors));
					if(!isset($newTerm->errors)){
					update_option('longitude-'.$newTerm['term_id'],$_POST['longitude']);
					update_option('latitude-'.$newTerm['term_id'],$_POST['latitude']);
					update_option('latlong_address-'.$newTerm['term_id'],$_POST['lati_longi_address']);
					wp_set_post_terms( get_the_ID(), $_POST['venueST'], 'venue-custom-category' );
					
					}
			}
		
		

		if(isset($_POST['linkST']))
			update_post_meta(get_the_ID(),'event-linkST',$_POST['linkST']);

		if(isset($_POST['URL']))
			update_post_meta(get_the_ID(),'event-url',$_POST['URL']);
	} // END function save_event_metabox($postObj){
} // END class event_post_metas
		
$object = new event_post_metas();
?>