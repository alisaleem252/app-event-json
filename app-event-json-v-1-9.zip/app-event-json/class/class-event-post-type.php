<?php // Registratoin of Event Management Class (Post Type)
class class_event_post_type{

	// Constructors of Event Management Class
	function __construct(){
		add_action('init', array(&$this,'class_event_post_type'));
		add_filter('manage_edit-events_columns', 'add_new_events_columns');
		add_action('manage_events_posts_custom_column', 'manage_events_columns', 10, 2);
		
	function add_new_events_columns($events_columns) {
		$new_columns['cb'] = '<input type="checkbox" />';
		 
		$new_columns['title'] = __('Title');
	    $new_columns['taxonomy-event-custom-category'] = __('Type of Event');
	    $new_columns['taxonomy-venue-custom-category'] = __('Venues');
		$new_columns['event_startdate'] = __('Date of Event');
		//$new_columns['event_enddate'] = __('Event End Date');
		$new_columns['date'] = __('Date');
		
		return $new_columns;
	}
	
	
		function manage_events_columns($column_name, $id) {
			switch ($column_name) {
				case 'event_startdate':
						print_r(get_post_meta($id,'event-startdate',true));
						break;
			 
				//case 'event_enddate':
				//	print_r(get_post_meta($id,'event-enddate',true));
				//	break;
				default:
					break;
			} // end switch

		} // function manage_events_columns($column_name, $id)
} // function __construct()
	
	  
	
	// Defining of Event Management Class
	function class_event_post_type(){
				register_post_type( 'events', array(
				'labels' => array(
				'name_admin_bar' => _x( 'Events', 'Add New Event' ),
				'name'=> 'All Events',
				'singular_name' => 'Event',
				'add_new' => 'Add Event',
				'add_new_item' => 'Add New Event',
				'edit' => 'Edit Event',
				'edit_item' => 'Edit Event',
				'new-item' => 'New Event',
				'view' => 'View Event',
				'view_item' => 'View Event',
				),
				'public'  => true,
				'menu_icon' => false,
				'capability_type' => 'post',
				'map_meta_cap' => true,
				'query_var' => false,
				'delete_with_user' => true,
				'supports' => array( 'title', 'thumbnail', 'editor'),
				'rewrite'  => array( 'slug' => 'event' ),
				)
				);
				flush_rewrite_rules();
			}   // END class_event_post_type
} // END class class_event_post_type
$object = new class_event_post_type();
?>