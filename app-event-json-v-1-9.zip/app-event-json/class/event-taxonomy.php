<?php // Creating/ Defining the Custom Taxonomy of Event Management Class      wp_insert_term('Beauty', 'theme');
class events_taxonomy{
		
		// constructor of events_taxonomy class
	function __construct(){
		add_action('init', array(&$this,'eventCustomTaxonomies'));
		add_action('venue-custom-category_edit_form_fields',array(&$this, 'inner_edit_form_fields')); 
		add_action('venue-custom-category_add_form_fields',array(&$this, 'main_edit_form_fields'));
		add_action ('edited_venue-custom-category',array(&$this,  'save_extra_fileds'));
		add_action('created_venue-custom-category',array(&$this, 'save_extra_fileds'));
	}
	
	
	function inner_edit_form_fields($currterm_object){
	$DB_latitude = get_option('latitude-'.$currterm_object->term_id);
	$DB_longitude = get_option('longitude-'.$currterm_object->term_id);
	$DB_latlong_address = get_option('latlong_address-'.$currterm_object->term_id);
	$latitude_DB = isset($DB_latitude) ? $DB_latitude : ''; 
	$longitude_DB = isset($DB_longitude) ? $DB_longitude : '' ;
	$latlongAddress_DB = isset($DB_latlong_address) ? $DB_latlong_address : '' ;
	?>
	<script> jQuery(document).ready(function(){ initialize(); }); </script>
		<tr>
			<th><?php _e( 'Click on the Required Venue for Latitude/Longetude', 'Eventmanagement'); ?></th>
			<td><div id="map_canvas" style="width: 785px; height: 400px"></div> <br />
				<input name="longlatitude" type="text" id="showlatlong" /> 
				<input type="button" id="longlatitudeBtn" value="Use This Lat/ Long" onclick="insertLatLong()" /><br /><br />
				Address: 	<input size="50px" id="lati_longi_address" name="lati_longi_address" type="text" value="<?php echo $latlongAddress_DB ?>" required />
				Latitude: 	<input size="12px" id="latitude" name="latitude" type="text" title="Enter Digists only" pattern="-?\d*\.{0,1}\d+" onchange="this.setCustomValidity(this.validity.patternMismatch ? '' : '');" required value="<?php echo $latitude_DB ?>" /> 
				Longitude:	<input size="12px" id="longitude" name="longitude" type="text" title="Enter Digists only" pattern="-?\d*\.{0,1}\d+" onchange="this.setCustomValidity(this.validity.patternMismatch ? '' : '');" required value="<?php echo $longitude_DB ?>" />
			</td>
		</tr>
			
	<?php 
	}
	
	function main_edit_form_fields(){ 
	
	?>
	
	<script> jQuery(document).ready(function(){ initialize(); }); </script>
		<h4><?php _e( 'Click on the Required Venue for Latitude/Longetude', 'Eventmanagement'); ?></h4>
		<div id="map_canvas" style="width: 350px; height: 200px"></div>
		Lat/ Longitude: <input name="longlatitude" type="text" id="showlatlong" /><br /> 
		Address: <input id="lati_longi_address" name="lati_longi_address" type="text" /> 
		<input type="button" id="longlatitudeBtn" value="Use This Lat/Long & Address" onclick="insertLatLong()" /><br /><br />
		<input id="latitude" name="latitude" type="text" title="Enter Digists only" /> <input id="longitude" name="longitude" type="text" />
	<?php 
	}
	
	 
	
	function save_extra_fileds($v_term_id){
		$latitude = $_POST["latitude"];
		$longitude = $_POST["longitude"];
		$latlong_address = $_POST["lati_longi_address"];
		update_option("latitude-$v_term_id",$latitude);
		update_option("longitude-$v_term_id",$longitude);
		update_option("latlong_address-$v_term_id",$latlong_address);
	} 
	
	
	
	
	// defining the eventCustomTaxonomies function
	function eventCustomTaxonomies(){
	
		//Types of Event Taxonomy
		$eventLabels = array(
			'name'              => _x( 'Types of Event', 'taxonomy general name'),
			'singular_name'     => _x( 'Type of Event', 'taxonomy singular name'),
			'search_items'      => __( 'Type of Event'),
			'all_items'         => __( 'All Types of Event'),
			'parent_item'       => __( 'Parent Type of Event'),
			'parent_item_colon' => __( 'Parent Type of Event'),
			'edit_item'         => __( 'Edit Type of Event'),
			'update_item'       => __( 'Update Type of Event'),
			'add_new_item'      => __( 'Add New Type of Event'),
			'new_item_name'     => __( 'New Type of Event'),
			'menu_name'         => __( 'Event Categories')
			);

			$event_args = array(
			'hierarchical'      => false,
			'labels'            => $eventLabels,
			'show_ui'           => true,
			'show_in_nav_menus' => true,
			'show_admin_column' => true,
			'show_in_menu' 		=> true,
			'query_var'         => true,
			'rewrite'           => array( 'slug' => 'events')
			);
			
			
		//The Venue Taxonomy
		$venueLabels = array(
			'name'              => _x( 'Venues', 'taxonomy general name'),
			'singular_name'     => _x( 'Venue', 'taxonomy singular name'),
			'search_items'      => __( 'Venue'),
			'all_items'         => __( 'All Venues'),
			'parent_item'       => __( 'Parent Venue'),
			'parent_item_colon' => __( 'Parent Venue'),
			'edit_item'         => __( 'Edit Venue'),
			'update_item'       => __( 'Update Venue'),
			'add_new_item'      => __( 'Add New Venue'),
			'new_item_name'     => __( 'New Venue'),
			'menu_name'         => __( 'Venues')
			);

			$venue_args = array(
			'hierarchical'      => false,
			'labels'            => $venueLabels,
			'show_ui'           => true,
			'show_in_nav_menus' => true,
			'show_admin_column' => true,
			'show_in_menu' 		=> true,
			'query_var'         => true,
			'meta_box_cb'       => false,
			'rewrite'           => array( 'slug' => 'venues')
			);
			register_taxonomy('event-custom-category','events',$event_args);
			register_taxonomy('venue-custom-category','events',$venue_args);
			
		
		

		
		
		
		
		
			
	flush_rewrite_rules();
	} // END function eventCustomTaxonomies()
} // END class :: class events_taxonomy
$object = new events_taxonomy();
?>