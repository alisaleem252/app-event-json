<?php
get_header();
//$date = '19:24'; 
//echo date('h:i A', strtotime($date));
?>
<div class="container event-meta" style="max-width:815px">
<div class="row">
<div class="col-md-12">
<!--<img src="<?php echo get_template_directory_uri() ?>/images/Facebook-Cover-Natur.jpg" /> -->
<?php  echo get_the_post_thumbnail(get_the_ID(),'full');?>
</div>
</div>
<div class="row">
<div class="col-md-12 event-header">
<?php the_post();
$venue = wp_get_post_terms( get_the_ID(), 'venue-custom-category');
$DB_latitude 	= isset($venue[0]) ? get_option('latitude-'.$venue[0]->term_id) : '';
$DB_longitude 	= isset($venue[0]) ? get_option('longitude-'.$venue[0]->term_id) : '';
$DB_address 	= isset($venue[0]) ? get_option('latlong_address-'.$venue[0]->term_id) : '';
?>
<h2 style=""><?php echo get_the_title();


	/* 				$eventTZ_DB = get_post_meta(get_the_ID(),'event-time-zone',true);
					$eventSD_DB = get_post_meta(get_the_ID(),'event-startdate',true);
					$eventST_DB = get_post_meta(get_the_ID(),'event-starttime',true);
					
					//date_default_timezone_set($eventTZ_DB);
					
	$dtz = new DateTimeZone($eventTZ_DB);
	$time_of_dtz = new DateTime("now", $dtz);
	$offset = $dtz->getOffset( $time_of_dtz ) / 60;
	print_r($dtz);
	echo '<br /><br />';

$db_dt_stamp = (strtotime("$eventSD_DB $eventST_DB"));
var_dump(($db_dt_stamp));
//echo "<br />db_timestamp == $db_timestamp <br />";
echo '<br /><br />';
//display the converted time
var_dump(Date('Y-m-d H:i A',strtotime("$offset minutes",strtotime(Date('Y-m-d h:i A')))));
echo '<br /><br />';
$current_dt_stamp = (strtotime("$offset minutes",strtotime(Date('Y-m-d h:i A'))));
var_dump($current_dt_stamp);
echo '<br /><br />';
var_dump(Date('Y-m-d H:i A'));

if($db_dt_stamp < $current_dt_stamp)
	echo 'Del';
else
		echo 'NO Del';
 */

 ?> 
										@ <?php echo get_post_meta(get_the_ID(),'event-venueST',true);?></h2>
			<div class="col-md-6 event-meta">
			<h3><i class="fa fa-calendar"></i> <?php echo get_post_meta(get_the_ID(),'event-startdate',true);?> <?php echo (get_post_meta(get_the_ID(), 'event-fulldayCB', true) == '') ? 'to '.get_post_meta(get_the_ID(),'event-enddate',true) : '( Full Day )' ?> </h3>
    		<p><?php echo date('h:i A', strtotime(get_post_meta(get_the_ID(),'event-starttime',true))); echo ((get_post_meta(get_the_ID(), 'event-fulldayCB', true) == '') ? ' - '.(date('h:i A', strtotime(get_post_meta(get_the_ID(),'event-endtime',true)))).'' : '') ?> </p>
			<?php ///if(get_post_meta(get_the_ID(),'event-safe',true) == 'on' ){?>
					<h3><i class="fa fa-compass"></i> <?php if($venue[0]->name) echo $venue[0]->name ;?></h3>
			<?php //} ?>		
    		<p><span id="venueaddress"><?php echo $DB_address ;?></span></p>
            <h3><i class="fa fa-link"></i> <a href="<?php echo get_post_meta(get_the_ID(),'event-url',true);?>" target="_blank"><?php echo get_post_meta(get_the_ID(),'event-linkST',true);?></a></h3>
            </div>  <!-- col-md-8 -->
            <div class="col-md-6">
            <div id="googleMap" style="height:200px" width="auto"></div>
            </div>  <!-- col-md-4 -->
             
</div>  <!-- col-md-12 -->
</div>  <!-- row -->
<div class="col-md-12" style="margin-top:25px;">
<p>
<?php echo get_the_content();?>
</p>
</div>
</div>  <!-- container -->
<!--script>
var geocoder;
var map;
var infowindow = new google.maps.InfoWindow();
var marker;
function initialize() {
  geocoder = new google.maps.Geocoder();
  var latlng = new google.maps.LatLng(<?php echo $DB_latitude ?>,<?php echo $DB_longitude?>);
  var mapOptions = {
    zoom: 8,
    center: latlng,
    mapTypeId: 'roadmap'
  }
  map = new google.maps.Map(document.getElementById('googleMap'), mapOptions);
    codeLatLng();
}

function codeLatLng() {
//  var input = document.getElementById('latlng').value;
//  var latlngStr = input.split(',', 2);
//  var lat = parseFloat(latlngStr[0]);
//  var lng = parseFloat(latlngStr[1]);
	<?php //if(get_post_meta(get_the_ID(),'event-safe',true) == 'on' ) { ?>
  var lat = parseFloat(<?php// echo $DB_latitude ?>);
  var lng = parseFloat(<?php// echo $DB_longitude ?>);
  var latlng = new google.maps.LatLng(lat, lng);
  geocoder.geocode({'latLng': latlng}, function(results, status) {
	  
    if (status == google.maps.GeocoderStatus.OK) {
      if (results[1]) {
        map.setZoom(11);
        marker = new google.maps.Marker({
            position: latlng,
            map: map
        });
//      console.log(results[1].formatted_address);
	  if (results[1].formatted_address)
	  jQuery('#venueaddress').text(results[1].formatted_address); 
	   // infowindow.setContent(results[1].formatted_address);
       // infowindow.open(map, marker);
      } else {
        alert('No results found');
      }
    } else {
      alert('Geocoder failed due to: ' + status);
    }
  });
  
  <?php //} // END if(get_post_meta(get_the_ID(),'event-safe',true) == 'on' )
		//else ?>
		//jQuery('#venueaddress').text("Venue Address is not set by Admin for this Event");
  
}

google.maps.event.addDomListener(window, 'load', initialize);

</script-->

<?php
get_footer();
?>