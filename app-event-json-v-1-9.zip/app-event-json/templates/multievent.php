<?php
get_header();
?>
<div class="container event-meta" style="max-width:815px">
	<?php
	if ( have_posts() ) : while ( have_posts() ) : the_post();
	?>
    <div class="row">
    <div class="col-md-12 image-topdistance">
    <div class="image-calender">
    	<div class="calender-div">
        <h2><?php 
		$date = get_post_meta(get_the_ID(),'event-startdate',true);
		$date = new DateTime($date);
		echo $date->format('d \<\b\\r\> M');
		?></h2>
    		<!--<h2>2 <br /> FEB</h2> -->
    	</div>
    </div>
    <a href="<?php echo get_permalink()?>"><?php echo get_the_post_thumbnail(get_the_ID(),'full');?></a>
    </div> <!-- col-md-12  -->
	</div> <!-- row -->
    <?php
	endwhile; else : ?>
	<p><?php _e( 'Sorry, no Event matched your criteria.' ); ?></p>
<?php endif;
	?>
</div> <!-- div conatiner -->
<?php
get_footer();
?>