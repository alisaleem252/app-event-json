<?php
	$eventArray = array();
	$eventPosts = get_posts(
							array(
									'showposts'	=> 50,
									'post_type'	=> 'events',
									'orderby' 	=> 'date',
									'order' 	=> 'ASC',
									'paged'		=>	isset($_REQUEST['pagenumber']) ? $_REQUEST['pagenumber'] : 1
								)
							);
	$totalevents = count($eventPosts);
	$contentArray = array();
	foreach ($eventPosts as $eventPost){
	$eventTypes = wp_get_post_terms($eventPost->ID, 'event-custom-category',array('fields'=> 'names'));
	$venue = wp_get_post_terms( $eventPost->ID, 'venue-custom-category');
	$DB_latitude = isset($venue[0]) ? get_option('latitude-'.$venue[0]->term_id) : '';
	$DB_longitude = isset($venue[0]) ? get_option('longitude-'.$venue[0]->term_id) : '';
	$DB_latlongAddress = isset($venue[0]) ? get_option('latlong_address-'.$venue[0]->term_id) : '';

//	var_dump($eventTypes);
		$contentArray[]['event']= array(
								'id' => $eventPost->ID,
								'title' => $eventPost->post_title,
								'startdate' => get_post_meta($eventPost->ID, 'event-startdate', true),
								'starttime' => get_post_meta($eventPost->ID, 'event-starttime', true),
								'enddate' => (get_post_meta($eventPost->ID, 'event-fulldayCB', true) == '') ? get_post_meta($eventPost->ID, 'event-enddate', true) : '',
								'endtime' => (get_post_meta($eventPost->ID, 'event-fulldayCB', true) == '') ? get_post_meta($eventPost->ID, 'event-endtime', true) : '',
								'venue' => ($venue[0]) ? $venue[0]->name : '',
								'latitude' => $DB_latitude,
								'longitude' => $DB_longitude,
								'address' => $DB_latlongAddress,
								'description' => esc_html($eventPost->post_content),
								'image' => wp_get_attachment_url( get_post_thumbnail_id($eventPost->ID)),
								'linktext' => get_post_meta($eventPost->ID, 'event-linkST', true),
								'url' => get_post_meta($eventPost->ID, 'event-url', true),
								'category' => isset($eventTypes[0]) ? $eventTypes[0] : '',
							);
	} // END foreach ($eventPosts as $eventPost)
	$phpArr4json['events'] = $contentArray;
	
	$eventsJSON = json_encode($phpArr4json);
	
	echo ($eventsJSON);
	
	$nowEventsArr = json_decode($eventsJSON,true);
	
	//	print_r( $nowEventsArr);
		
?>