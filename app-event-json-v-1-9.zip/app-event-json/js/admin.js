	jQuery(document).ready(function(){
		// Fullday checkbox Event Controlling Block
		{ // BLOCK Start			
					if(jQuery('#fulldayCB').is(":checked")){
						
						jQuery("#enddateRow").fadeOut('slow', function(){ 
							jQuery(this).attr('style', 'display:none');
						});
						
						jQuery('#enddate').prop('disabled', 'disabled');
						jQuery('#endtime').prop('disabled', 'disabled');
					}
					else{
							jQuery("#enddateRow").fadeIn('slow', function(){ 
							jQuery(this).attr('style', 'display');
						});
						
						jQuery('#enddate').prop('disabled', false);
						jQuery('#endtime').prop('disabled', false);
					}
				jQuery('#fulldayCB').click(function(){
					if(jQuery(this).is(":checked")){
						jQuery("#enddateRow").fadeOut('slow', function(){ 
							jQuery(this).attr('style', 'display:none');
						});
						
						jQuery('#enddate').prop('disabled', 'disabled');
						jQuery('#endtime').prop('disabled', 'disabled');
					}
					else{
							jQuery("#enddateRow").fadeIn('slow', function(){ 
							jQuery(this).attr('style', 'display');
						});
						jQuery('#enddate').prop('disabled', false);
						jQuery('#endtime').prop('disabled', false);
					}
				}); // END jQuery('#fulldayCB').click(function()
		} // END fullday checkbox control BLOCK
////////////////////////////////////////////////////////////////////////////////////////////////////		

				jQuery('#startdate').change(function(){
					jQuery('#enddate').attr('min',jQuery(this).val());
					jQuery('#enddate').attr('value',jQuery(this).val());	
				}); // END jQuery('#startdate').click(function()
				
				
	}); // END jQuery(document).ready(function()	


	// function :: giving seperated value of Latitude and Longitude
	function insertLatLong(){
		splitlatlong = (jQuery('#showlatlong').val()).split(',');
		jQuery('#latitude').val(splitlatlong[0]); 	// latitude
		jQuery('#longitude').val(splitlatlong[1]); 	// longitude
	}
