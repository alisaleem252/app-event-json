	// function :: giving seperated value of Latitude and Longitude
	function insertLatLong(){
		splitlatlong = (jQuery('#showlatlong').val()).split(',');
		jQuery('#latitude').val(splitlatlong[0]); 	// latitude
		jQuery('#longitude').val(splitlatlong[1]); 	// longitude
	}


    var map = null;
    var geocoder = null;
    function initialize() {
      if (GBrowserIsCompatible()) {
        map = new GMap2(document.getElementById("map_canvas"));
        //console.log(map);
		map.setCenter(new GLatLng(37.4419, -122.1419),8);
        map.addControl(new GSmallZoomControl());
        geocoder = new GClientGeocoder();
        GEvent.addListener(map, "click", clicked);
        map.openInfoWindow(map.getCenter(), "Click the map!");
      }
    }

	
	
    function clicked(overlay, latlng) {
	
      if (latlng) {
        geocoder.getLocations(latlng, function(addresses) {
		//console.log(addresses);
          if(addresses.Status.code != 200) {
     //       alert("reverse geocoder failed to find an address for " + latlng.toUrlValue());
          }
          else {
            //console.log(addresses);
            var myaddress = addresses.Placemark[0].address;
			var lati_longi = addresses.name;
            map.openInfoWindow(latlng, myaddress);
			jQuery('#showlatlong').val(lati_longi);
			jQuery('#lati_longi_address').val(myaddress);
          }
        });
      }
    }
	
function showAddress(address) {
      if (geocoder) {
        geocoder.getLatLng(address,function(point) {
            if (!point) {
        //      alert(address + " not found");
            } else {
              map.setCenter(point, 15);
            } // else
          }
        );
      }
    }